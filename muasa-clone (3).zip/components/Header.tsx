"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X, ChevronDown } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isServicesOpen, setIsServicesOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-slate-900/95 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-12 h-12 relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-blue-600 transform rotate-45 rounded-sm"></div>
              <div className="absolute top-1 left-1 w-4 h-4 bg-red-500 rounded-sm"></div>
              <div className="absolute bottom-1 right-1 w-4 h-4 bg-blue-700 rounded-sm"></div>
            </div>
            <div className="text-white">
              <div className="text-xl font-bold tracking-wide">MUASA</div>
              <div className="text-xs tracking-wider opacity-90">SOLUTIONS PVT LTD</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link href="/" className="text-white hover:text-blue-300 transition-colors font-medium">
              Home
            </Link>
            <Link href="#about" className="text-white hover:text-blue-300 transition-colors font-medium">
              About Us
            </Link>

            {/* Services Dropdown */}
            <div
              className="relative"
              onMouseEnter={() => setIsServicesOpen(true)}
              onMouseLeave={() => setIsServicesOpen(false)}
            >
              <button className="text-white hover:text-blue-300 transition-colors font-medium flex items-center">
                Services
                <ChevronDown className={`ml-1 w-4 h-4 transition-transform ${isServicesOpen ? "rotate-180" : ""}`} />
              </button>

              {isServicesOpen && (
                <div className="absolute top-full left-0 mt-2 w-80 bg-white rounded-lg shadow-xl border overflow-hidden">
                  <div className="p-2">
                    <Link
                      href="#services"
                      className="block p-3 hover:bg-gray-50 rounded-lg text-gray-700 hover:text-blue-600"
                    >
                      <div className="font-semibold">Website Development</div>
                      <div className="text-sm text-gray-500">Custom web solutions</div>
                    </Link>
                    <Link
                      href="#services"
                      className="block p-3 hover:bg-gray-50 rounded-lg text-gray-700 hover:text-blue-600"
                    >
                      <div className="font-semibold">Digital Marketing</div>
                      <div className="text-sm text-gray-500">SEO, SEM, Social Media</div>
                    </Link>
                    <Link
                      href="#services"
                      className="block p-3 hover:bg-gray-50 rounded-lg text-gray-700 hover:text-blue-600"
                    >
                      <div className="font-semibold">App Development</div>
                      <div className="text-sm text-gray-500">Mobile applications</div>
                    </Link>
                    <Link
                      href="#services"
                      className="block p-3 hover:bg-gray-50 rounded-lg text-gray-700 hover:text-blue-600"
                    >
                      <div className="font-semibold">Brand Consulting</div>
                      <div className="text-sm text-gray-500">Brand strategy & positioning</div>
                    </Link>
                  </div>
                </div>
              )}
            </div>

            <Link href="#projects" className="text-white hover:text-blue-300 transition-colors font-medium">
              Projects
            </Link>
            <Link href="#clients" className="text-white hover:text-blue-300 transition-colors font-medium">
              Clients
            </Link>
            <Link href="#team" className="text-white hover:text-blue-300 transition-colors font-medium">
              Our Team
            </Link>
            <Link href="#contact" className="text-white hover:text-blue-300 transition-colors font-medium">
              Contact Us
            </Link>
          </nav>

          {/* Contact Info & CTA */}
          <div className="hidden lg:flex items-center space-x-6">
            <div className="text-right text-white">
              <div className="text-sm opacity-80">Consultation</div>
              <div className="font-semibold">(571) 517-1514</div>
            </div>
            <Link
              href="#contact"
              className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-6 py-3 rounded-full font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all duration-300"
            >
              START A PROJECT
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="lg:hidden text-white p-2">
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden pt-4 pb-2 space-y-2">
            <Link href="/" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              Home
            </Link>
            <Link href="#about" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              About Us
            </Link>
            <Link href="#services" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              Services
            </Link>
            <Link href="#projects" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              Projects
            </Link>
            <Link href="#clients" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              Clients
            </Link>
            <Link href="#team" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              Our Team
            </Link>
            <Link href="#contact" className="block px-4 py-3 text-white hover:bg-blue-500/20 rounded-lg">
              Contact Us
            </Link>
          </div>
        )}
      </div>
    </header>
  )
}
